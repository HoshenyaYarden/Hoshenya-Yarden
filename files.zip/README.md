# Hoshenya-Yarden Photography

אתר תיק עבודות לצלם/ת, בנוי ב-React + Vite.

## הרצה מקומית

```bash
npm install
npm run dev
```

האתר ייפתח בכתובת מקומית (בדרך כלל `http://localhost:5173`).

## בנייה לפרסום

```bash
npm run build
```

התוצר ייכנס לתיקיית `dist/`.

## פרסום ל-GitHub Pages

1. ודאו ש-`vite.config.js` מכיל `base: "/Hoshenya-Yarden/"` (בהתאם לשם הריפו שלכם).
2. הריצו:
   ```bash
   npm install --save-dev gh-pages
   npx gh-pages -d dist
   ```
   (או הגדירו GitHub Action שבונה ומפרסמת אוטומטית בכל push ל-`main`.)
3. באתר ה-GitHub של הריפו: Settings → Pages → בחרו את הענף `gh-pages`.

## פרסום ב-Vercel / Netlify (מומלץ — הכי פשוט)

1. התחברו עם GitHub ב-[vercel.com](https://vercel.com) או [netlify.com](https://netlify.com).
2. יבאו (Import) את הריפו הזה.
3. Build command: `npm run build`, Output directory: `dist`.
4. אם משתמשים ב-Vercel/Netlify, אפשר להחזיר את `base` בקובץ `vite.config.js` ל-`"/"`.

## הערה חשובה על שמירת הנתונים

הגרסה הזו שומרת את התוכן (טקסטים ותמונות) ב-**localStorage של הדפדפן**. המשמעות:

- השינויים נשמרים רק בדפדפן שבו נעשתה העריכה — מבקרים אחרים באתר **לא** יראו את העדכונים.
- תמונות רבות/כבדות עלולות לחרוג ממגבלת האחסון של הדפדפן (בסביבות 5-10MB).
- אחרי ניקוי היסטוריית הדפדפן (cache/site data) התוכן שנערך יימחק.

זה מתאים כדוגמה/דמו, אבל **לא** לאתר production אמיתי שבו אתם רוצים לערוך תוכן ושכולם יראו את זה. לכך צריך backend אמיתי (מסד נתונים + אחסון תמונות בענן, למשל Cloudinary/S3, וממשק ניהול מאובטח).
